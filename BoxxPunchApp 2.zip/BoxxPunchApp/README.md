# Boxx Punch iPhone app

SwiftUI + CoreBluetooth proof-of-concept pentru Boxx Punch Pods.

UUID observate:
- Service: DE8A5AAC-A99B-C315-0C80-60D4CBB51224
- Characteristic: 61A885A4-41C3-60D0-9A53-6D652A70D29C (Read/Write/Notify)

Important: aplicația activează Notify prin `setNotifyValue(true, for:)`. Pe iOS nu trebuie scris manual `0100` în descriptorul 2902.

## În Xcode
1. Creează un proiect iOS App numit `BoxxPunchApp`, SwiftUI + Swift.
2. Înlocuiește fișierele Swift cu cele din folderul `BoxxPunchApp/`.
3. În Info.plist adaugă `Privacy - Bluetooth Always Usage Description` cu textul `Conectare la senzorii Boxx Punch Pods`.
4. Selectează iPhone-ul ca target, setează Team/Signing și rulează pe telefon (BLE nu se testează complet în Simulator).
5. Pornește senzorii. App caută un device al cărui nume conține Boxx/Punch, descoperă toate serviciile/caracteristicile și activează automat Notify pe toate caracteristicile compatibile.

Următorul pas: lovește LEFT și RIGHT separat și copiază liniile `RX ...` din jurnal. Cu acele pachete se poate implementa decodarea exactă LEFT/RIGHT, forță și viteză.
