import SwiftUI

struct ContentView: View {
    @StateObject private var ble = BLEManager()

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Text("🥊 Boxx Punch")
                    .font(.largeTitle.bold())
                Text(ble.status).font(.headline)
                Text("Dispozitiv: \(ble.connectedName)").foregroundStyle(.secondary)

                HStack(spacing: 35) {
                    VStack { Text("LOVITURI").font(.caption); Text("\(ble.punchCount)").font(.system(size: 52, weight: .bold)) }
                    VStack { Text("ULTIMUL PACHET").font(.caption); Text(ble.lastPacket).font(.system(.body, design: .monospaced)).lineLimit(3) }
                }

                Button("Reconectează") { ble.reconnect() }.buttonStyle(.borderedProminent)

                List(ble.log, id: \.self) { line in
                    Text(line).font(.system(size: 11, design: .monospaced))
                }
            }
            .padding(.top)
            .navigationTitle("Boxx Punch Pods")
        }
    }
}
