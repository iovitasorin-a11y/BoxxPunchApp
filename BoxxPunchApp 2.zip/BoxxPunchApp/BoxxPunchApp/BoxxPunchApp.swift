import SwiftUI

@main
struct BoxxPunchApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
