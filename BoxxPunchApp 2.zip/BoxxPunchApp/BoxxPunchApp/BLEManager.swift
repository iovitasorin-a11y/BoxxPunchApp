import Foundation
import CoreBluetooth

final class BLEManager: NSObject, ObservableObject {
    @Published var status = "Bluetooth: inițializare…"
    @Published var connectedName = "—"
    @Published var lastPacket = "—"
    @Published var punchCount = 0
    @Published var log: [String] = []

    private var central: CBCentralManager!
    private var peripheral: CBPeripheral?

    // UUID-urile observate în Boxx Punch Pods.
    private let targetService = CBUUID(string: "DE8A5AAC-A99B-C315-0C80-60D4CBB51224")
    private let knownCharacteristic = CBUUID(string: "61A885A4-41C3-60D0-9A53-6D652A70D29C")

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func reconnect() {
        if let p = peripheral { central.cancelPeripheralConnection(p) }
        scan()
    }

    private func scan() {
        guard central.state == .poweredOn else { return }
        status = "Caut Boxx Punch Pods…"
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
    }

    private func addLog(_ text: String) {
        let t = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        log.insert("\(t)  \(text)", at: 0)
        if log.count > 100 { log.removeLast() }
    }

    private func hex(_ data: Data) -> String { data.map { String(format: "%02X", $0) }.joined(separator: " ") }
}

extension BLEManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn: status = "Bluetooth pornit"; scan()
        case .poweredOff: status = "Pornește Bluetooth"
        case .unauthorized: status = "Permite Bluetooth pentru aplicație"
        default: status = "Bluetooth indisponibil"
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let name = peripheral.name ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? ""
        guard name.localizedCaseInsensitiveContains("Boxx") || name.localizedCaseInsensitiveContains("Punch") else { return }
        central.stopScan()
        self.peripheral = peripheral
        peripheral.delegate = self
        status = "Conectare…"
        central.connect(peripheral)
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        connectedName = peripheral.name ?? "Boxx Punch Pods"
        status = "Conectat"
        addLog("Conectat: \(connectedName)")
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        status = "Deconectat — caut din nou…"
        connectedName = "—"
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { self.scan() }
    }
}

extension BLEManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil else { addLog("Eroare servicii: \(error!.localizedDescription)"); return }
        for service in peripheral.services ?? [] {
            addLog("Service \(service.uuid.uuidString)")
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else { return }
        for c in service.characteristics ?? [] {
            let props = c.properties
            addLog("Char \(c.uuid.uuidString) props=\(props.rawValue)")

            // CoreBluetooth configurează CCCD (2902) automat. Nu scriem manual 0100.
            if props.contains(.notify) || props.contains(.indicate) {
                peripheral.setNotifyValue(true, for: c)
                addLog("Notify cerut: \(c.uuid.uuidString)")
            }
            if props.contains(.read) { peripheral.readValue(for: c) }

            if service.uuid == targetService && c.uuid == knownCharacteristic {
                addLog("Caracteristica Boxx cunoscută găsită")
            }
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error { addLog("Notify ERROR \(characteristic.uuid): \(error.localizedDescription)") }
        else { addLog("Notify \(characteristic.isNotifying ? "ON" : "OFF") \(characteristic.uuid.uuidString)") }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, let data = characteristic.value else { return }
        let packet = hex(data)
        lastPacket = packet
        addLog("RX \(characteristic.uuid.uuidString): \(packet)")

        // Pentru început numărăm orice notificare primită. După capturarea pachetelor
        // de la lovituri putem separa LEFT/RIGHT și calcula forța/viteza.
        if characteristic.isNotifying && !data.isEmpty { punchCount += 1 }
    }
}
